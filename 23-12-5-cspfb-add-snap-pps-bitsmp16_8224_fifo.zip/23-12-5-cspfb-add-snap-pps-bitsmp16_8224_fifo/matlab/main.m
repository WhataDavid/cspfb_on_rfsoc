Raw = importRawCO("D:\xilinxProjects\PFB2560to128\matlab\Raw.coe");
%% 
for i = 1:20
    filename = sprintf('fir%d.coe', i-1);
    fp = fopen(filename, 'wt');
    fprintf(fp, 'Radix = 16; \nCoefficient_Width = 16; \nCoefData = ');
    for j=1:(length(Raw) / 20 - 1)
        fprintf(fp, Raw(20*(j-1) + i));
        fprintf(fp, ',\n');
    end
    fprintf(fp, Raw(length(Raw) - 20 + i));
    fprintf(fp, ';\n');
    fclose(fp);
end