fs = 2560e6;
t = 0:(1/fs):(1/fs*5000);
fs1 = 128e6;
t1 = 0:(1/fs1):(1/fs1*5000);
data = sin(2*pi*1410e6*t) + sin(2*pi*1540e6*t) + sin(2*pi*1670e6*t) + sin(2*pi*1800e6*t) ...
+ sin(2*pi*1930e6*t) + sin(2*pi*2060e6*t) + sin(2*pi*2190e6*t) + sin(2*pi*2320e6*t);
q_y=round(data*(2^12 -1));
plot(q_y);
fid=fopen('.\signal.txt','w');
for i = 1:length(t)
    fprintf(fid, dec2hex(q_y(i),4));
    fprintf(fid, '\n');
end
x1 = 0:2559;
x2 = (0:1279)/10;
fclose(fid);
figure;
plot(x1,abs(fft(data,2560)));
xlabel('fre(MHz)');

figure;
subplot(4,2,1);
plot(x2,abs(fft(exp(1j*2*pi*2e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,2);
plot(x2,abs(fft(exp(1j*2*pi*4e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,3);
plot(x2,abs(fft(exp(1j*2*pi*6e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,4);
plot(x2,abs(fft(exp(1j*2*pi*8e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,5);
plot(x2,abs(fft(exp(1j*2*pi*10e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,6);
plot(x2,abs(fft(exp(1j*2*pi*12e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,7);
plot(x2,abs(fft(exp(1j*2*pi*14e6*t1),1280)));
xlabel('fre(MHz)');

subplot(4,2,8);
plot(x2,abs(fft(exp(1j*2*pi*16e6*t1),1280)));
xlabel('fre(MHz)');
