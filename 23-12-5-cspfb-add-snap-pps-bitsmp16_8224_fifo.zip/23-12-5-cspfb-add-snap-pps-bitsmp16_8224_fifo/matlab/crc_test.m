a = uint64(fliplr(dec2bin(0x2122030405060708,64)));
c = dec2hex(bin2dec(b));